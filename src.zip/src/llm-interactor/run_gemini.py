from google import genai
import time
import os
import json
from llm_utils import load_jsonl, parse_result 
client = genai.Client(api_key="###")

# Define root folder and paths
# dataset_name = "dbpedia_webnlg"
# dataset_name = "wikidata_tekgen"
dataset_name = "webnlg"    
prompt_folder_name = "5shot_prompt"   
root_folder = "cikm25/dataset_preprocessing/" + dataset_name
prompts_folder = os.path.join(root_folder, "prompts", prompt_folder_name)

# open the output folder
output_folder_path = os.path.join(root_folder, "llm_output", "gemini-1.5-flash-8b")	
os.makedirs(output_folder_path, exist_ok=True) 
# Set up logging
from datetime import datetime
import sys

# Create log filename with current date and time
start_processing_time = datetime.now().strftime('%Y%m%d_%H%M%S')
log_filename = f'run_log_{start_processing_time}.txt'
log_filepath = os.path.join(root_folder, 'logs')
os.makedirs(log_filepath, exist_ok=True)
log_filepath = os.path.join(log_filepath, log_filename)

# Create a custom class to capture both console and file output
class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, 'w', encoding='utf-8')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        self.terminal.flush()
        self.log.flush()

# Redirect stdout to both console and log file
sys.stdout = Logger(log_filepath)

print(f"Starting processing at {start_processing_time}")
print(f"Dataset: {dataset_name}")
print(f"Root folder: {root_folder}")
print(f"Prompts folder: {prompts_folder}")
print(f"Output folder: {output_folder_path}")


""" # List only subfolders starting with 'merged'
selected_dirs = [d for d in os.listdir(prompts_folder) if d.startswith('similar')]
# Walk through only selected subfolders
print("\nProcessing prompts...")
for subdir in selected_dirs:
    root = os.path.join(prompts_folder, subdir)
    for file in os.listdir(root):  """

# Walk through prompts folder and process each file
print("\nProcessing prompts...")
for root, dirs, files in os.walk(prompts_folder):   
    for file in files: 
        # --------------------------------------------------------
        if file.endswith('.jsonl'):
            # Print current subfolder being processed
            print(f"\nProcessing subfolder: {root}")
            print("-" * 80)
            print(f"\nProcessing file: {file}")
            
            # Get relative path from prompts folder to create same structure in output
            rel_path = os.path.relpath(root, prompts_folder)
            
            # Create corresponding output directory
            output_subdir = os.path.join(output_folder_path, rel_path)
            os.makedirs(output_subdir, exist_ok=True)

            # Get input file path
            input_file_path = os.path.join(root, file)

            # Parse filename to create output filename
            # Take everything up to _prompt from the original filename
            output_filename = file.split('_prompt')[0] + '_results.jsonl'
            output_file_path = os.path.join(output_subdir, output_filename)
            print(f"Output will be saved to: {output_file_path}")

            # Load input data
            input_data = load_jsonl(input_file_path)

            with open(output_file_path, "a", encoding="utf-8") as f_out:  # use .jsonl for line-by-line records
                for data in input_data:
                    prompt = data["prompt"]
                    if prompt is None:
                        print(f"Prompt not found")
                    else:
                        # Prompt sent to the LLM
                        start_time = time.time()
                        generation_config = {
                            "temperature": 0,
                            "max_output_tokens": 1000
                        }
                        try:
                            response = client.models.generate_content(
                                model="gemini-1.5-flash-8b", 
                                contents=prompt,
                                config=generation_config
                            )
                            end_time = time.time()
                            print(f"got result in {end_time - start_time} second")
                            print(f"Response: {response.text}")

                            result = response.text
                            run_time = end_time - start_time
                            usage = str(response.usage_metadata)
                            triples = parse_result(result)

                            output_item = {
                                "id": data["id"],
                                "prompt": prompt,
                                "result": result,
                                "run_time": run_time,
                                "usage_metadata": usage,
                                "triples": triples
                            }

                            # Write to file immediately
                            f_out.write(json.dumps(output_item, ensure_ascii=False) + "\n")

                        except Exception as e:
                            end_time = time.time()
                            print(f"Error during content generation: {e}")
                            print(f"Failed after {end_time - start_time} second")



end_processing_time = datetime.now().strftime("%Y%m%d_%H%M%S")
processing_time = datetime.strptime(end_processing_time, "%Y%m%d_%H%M%S") - datetime.strptime(start_processing_time, "%Y%m%d_%H%M%S")

with open(log_filepath, "a", encoding="utf-8") as log_f:
    log_f.write(f"\nProcessing completed at {end_processing_time}")
    log_f.write(f"\nProcessing time: {processing_time}")    


