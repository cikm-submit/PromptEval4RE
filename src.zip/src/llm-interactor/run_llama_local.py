import time
import os
import json
from llm_utils import load_jsonl, parse_result
from langchain import PromptTemplate, LLMChain
from datetime import datetime
import sys
from langchain_community.llms import Ollama
from langchain.schema.messages import HumanMessage

# Define root folder and paths
#dataset_name = "wikidata_tekgen"
dataset_name = "dbpedia_webnlg"  
root_folder = os.path.join(r"root_folder", dataset_name)
prompts_folder = os.path.join(root_folder, "prompts")

# Output folder
output_folder_path = os.path.join(root_folder, "llm_output", "llama-1b")
os.makedirs(output_folder_path, exist_ok=True) 

# Set up logging
start_processing_time = datetime.now().strftime('%Y%m%d_%H%M%S')
log_filename = f'run_log_{start_processing_time}.txt'
log_filepath = os.path.join(root_folder, 'logs')
os.makedirs(log_filepath, exist_ok=True)
log_filepath = os.path.join(log_filepath, log_filename)

class Logger:
    def __init__(self, filename):
        self.terminal = sys.stdout
        self.log = open(filename, 'w', encoding='utf-8')

    def write(self, message):
        self.terminal.write(message)
        self.log.write(message)
        self.log.flush()

    def flush(self):
        self.terminal.flush()
        self.log.flush()

sys.stdout = Logger(log_filepath)

print(f"Starting processing at {start_processing_time}")
print(f"Dataset: {dataset_name}")
print(f"Root folder: {root_folder}")
print(f"Prompts folder: {prompts_folder}")
print(f"Output folder: {output_folder_path}")

# Set up local LLaMA model
llm = Ollama(
    model="llama3.2:1b",  # llama3_1b model: "llama3.2:1b", llama3_7b model: "llama3.1"
    temperature=0,
    base_url="http://localhost:11434"
)

print("\nProcessing prompts...")
for root, dirs, files in os.walk(prompts_folder):   
    for file in files: 
        if file.endswith('.jsonl'):
            print(f"\nProcessing subfolder: {root}")
            print("-" * 80)
            print(f"\nProcessing file: {file}")

            rel_path = os.path.relpath(root, prompts_folder)
            output_subdir = os.path.join(output_folder_path, rel_path)
            os.makedirs(output_subdir, exist_ok=True)

            input_file_path = os.path.join(root, file)
            output_filename = file.split('_prompt')[0] + '_results.jsonl'
            output_file_path = os.path.join(output_subdir, output_filename)
            print(f"Output will be saved to: {output_file_path}")

            input_data = load_jsonl(input_file_path)

            with open(output_file_path, "a", encoding="utf-8") as f_out:
                for data in input_data:
                    prompt = data["prompt"]
                    if prompt is None:
                        print(f"Prompt not found")
                    else:
                        start_time = time.time()
                        try:
                            result = llm.invoke([HumanMessage(content=prompt)])
                            #result = response.content
                            end_time = time.time()
                            print(f"got result in {end_time - start_time} second")
                            print(f"Response: {result}")

                            run_time = end_time - start_time
                            usage = "n/a for local LLM"
                            triples = parse_result(result)

                            output_item = {
                                "id": data["id"],
                                "prompt": prompt,
                                "result": result,
                                "run_time": run_time,
                                "usage_metadata": usage,
                                "triples": triples
                            }

                            f_out.write(json.dumps(output_item, ensure_ascii=False) + "\n")

                        except Exception as e:
                            end_time = time.time()
                            print(f"Error during content generation: {e}")
                            print(f"Failed after {end_time - start_time} second")

end_processing_time = datetime.now().strftime("%Y%m%d_%H%M%S")
processing_time = datetime.strptime(end_processing_time, "%Y%m%d_%H%M%S") - datetime.strptime(start_processing_time, "%Y%m%d_%H%M%S")

with open(log_filepath, "a", encoding="utf-8") as log_f:
    log_f.write(f"\nProcessing completed at {end_processing_time}")
    log_f.write(f"\nProcessing time: {processing_time}")
