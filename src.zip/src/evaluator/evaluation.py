import os
import sys

# Add the parent directory to the path so utils and eval_utils can be imported
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import eval_utils
import utils

############################## Change dataset and model directory
root_folder = os.path.join("cikm25")
result_folder = os.path.join("cikm25", "results")
data_folder = os.path.join(root_folder, "dataset_preprocessing", )

dataset_name = "dbpedia_webnlg"
dataset_name = "wikidata_tekgen"
dataset_name = "webnlg"


model_name = "deepseek-v3"  
model_name = "gemini-1.5-flash-8b"
model_name = "llama3-8b"
model_name = "llama3-1b"

subfolder_name = "1shot"
#subfolder_name = "3shot"
#subfolder_name = "5shot"

ontology_folder = os.path.join(data_folder, dataset_name, 'ontologies')
ground_truth_folder = os.path.join(data_folder, dataset_name, 'ground_truth') 
model_folder = os.path.join(result_folder, dataset_name, "llm_output", model_name)
output_folder = os.path.join(result_folder, dataset_name, "llm_output", model_name, subfolder_name)

############################## Walk through all subdirectories in the model folder
for setting_folder in os.listdir(output_folder):
    setting_path = os.path.join(output_folder, setting_folder)
    if not os.path.isdir(setting_path):
        continue

    eval_folder = os.path.join(setting_path, "eval")
    os.makedirs(eval_folder, exist_ok=True)

    global_eval_folder = os.path.join(model_folder, "global_eval")
    os.makedirs(global_eval_folder, exist_ok=True)

    total_files = 0
    t_p, t_r, t_f1, t_onto_conf, t_rel_halluc = 0, 0, 0, 0, 0
    total_sentences = 0

    for filename in os.listdir(setting_path):
        if not filename.endswith(".jsonl"):
            continue

        total_files += 1
        file_path = os.path.join(setting_path, filename)
        print(f"Processing file: {file_path}")
        system_output = utils.load_jsonl(file_path)
        system_output = eval_utils.convert_to_dict(system_output)

        ontology_id = "_".join(filename.split("_")[:2])
        ground_truth_file_path = os.path.join(ground_truth_folder, f"ont_{ontology_id}_ground_truth.jsonl")

        ground_truth = utils.load_jsonl(ground_truth_file_path)
        ground_truth = eval_utils.convert_to_dict(ground_truth)

        ########## Load ontology
        # Choose ontology file based on filename content
        if "merged" in filename:
            ontology_file_path = os.path.join(ontology_folder, "merged_ontology.json")
            print(f"Using merged ontology for {filename}")
        else:
            ontology_file_path = os.path.join(ontology_folder, f"{ontology_id}_ontology.json")
        ontology = utils.load_json(ontology_file_path)

        file_eval_metrics = []
        f_p, f_r, f_f1, f_onto_conf, f_rel_halluc = 0, 0, 0, 0, 0

        for sent_id, data in system_output.items():
            system_triples = data['triples']
            if sent_id not in ground_truth:
                continue

            gt_triples = [[tr['sub'], tr['rel'], tr['obj']] for tr in ground_truth[sent_id]['triples']]
            sentence = ground_truth[sent_id]['sent']
            gt_relations = {tr[1].replace(" ", "_") for tr in gt_triples}
            filtered_system_triples = [tr for tr in system_triples if tr[1] in gt_relations]

            normalized_system = {eval_utils.normalize_triple(*tr) for tr in filtered_system_triples}
            normalized_gt = {eval_utils.normalize_triple(*tr) for tr in gt_triples}

            precision, recall, f1 = eval_utils.calculate_precision_recall_f1(normalized_gt, normalized_system)
            ont_conf, rel_halluc = eval_utils.get_ontology_conformance(ontology, system_triples)

            f_p += precision
            f_r += recall
            f_f1 += f1
            f_onto_conf += ont_conf
            f_rel_halluc += rel_halluc


            file_eval_metrics.append({
                "id": sent_id,
                "precision": f"{precision * 100:.1f}%",
                "recall": f"{recall * 100:.1f}%",
                "f1": f"{f1 * 100:.1f}%",
                "onto_conf": f"{ont_conf * 100:.1f}%",
                "rel_halluc": f"{rel_halluc * 100:.1f}%",
                "llm_triples": system_triples,
                "filtered_llm_triples": filtered_system_triples,
                "gt_triples": gt_triples,
                "sent": sentence,
                "normalized_llm_triples": list(normalized_system),
                "normalized_gt_triples": list(normalized_gt)
            })

        total_sents = len(system_output)
        total_sentences += total_sents
        utils.save_json(file_eval_metrics, os.path.join(eval_folder, f"{filename.split('.')[0]}_eval_output.json"))

        if total_sents > 0:
            file_avg_metrics = {
                "avg_precision": f"{(f_p / total_sents) * 100:.1f}%",
                "avg_recall": f"{(f_r / total_sents) * 100:.1f}%",
                "avg_f1": f"{(f_f1 / total_sents) * 100:.1f}%",
                "avg_onto_conf": f"{(f_onto_conf / total_sents) * 100:.1f}%",
                "avg_rel_halluc": f"{(f_rel_halluc / total_sents) * 100:.1f}%"
            }
            utils.save_json(file_avg_metrics, os.path.join(eval_folder, f"{filename.split('.')[0]}_metrics.json"))

            # Update global counters for this folder
            t_p += f_p
            t_r += f_r
            t_f1 += f_f1
            t_onto_conf += f_onto_conf
            t_rel_halluc += f_rel_halluc

    if total_files > 0 and total_sentences > 0:
        folder_avg_metrics = {
            "avg_precision": f"{(t_p / total_sentences) * 100:.1f}%",
            "avg_recall": f"{(t_r / total_sentences) * 100:.1f}%",
            "avg_f1": f"{(t_f1 / total_sentences) * 100:.1f}%",
            "avg_onto_conf": f"{(t_onto_conf / total_sentences) * 100:.1f}%",
            "avg_rel_halluc": f"{(t_rel_halluc / total_sentences) * 100:.1f}%"
        }
        utils.save_json(folder_avg_metrics, os.path.join(global_eval_folder, f"{setting_folder}_global_metrics.json"))